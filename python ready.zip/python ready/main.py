from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from tkinter.scrolledtext import ScrolledText
from tkinter import colorchooser
import csv
import random

root = Tk()
root.withdraw()

## Same category name error
## Add new category into welcome page if no questions availiable
## Create file when not found

## Title things in welcome drop down
## FocusIn & FocusOut
## Change the change category window size
## .lower the inputs to allow capitaled inputs
## Cleanup NewOrEditQuestion


#------------
dataFile = 'questions.csv'
bfont35 = 'Calibri 35 bold'
font24 = 'Calibri 24'
font20 = 'Calibri 20'
#------------

def Questions(event=None):
    '''Gives a matrix of questions in seperate lists
    with the category name as the index 0'''
    
    global questionList, category
    questionList = []
    category = []
    
    with open(dataFile,'r') as data:
        read = csv.reader(data)
        for row in read:
            #print(row)
            questionList.append(row)
            if row[0] not in category:
                category.append(row[0])



class Welcome:
    def __init__(self, maintext, image=True):
        '''Class used for changing categories as well as the first welcome page'''

        self.maintext = maintext

        ## changes to other files if not found (for school purposes)
        try:
            self.tick = PhotoImage(file='tick.png')
            self.cross = PhotoImage(file='cross.png')
        except:
            self.tick = PhotoImage(file='tick2.gif')
            self.cross = PhotoImage(file='cross2.gif')
        
        self.window = Toplevel()
        self.window.title(maintext)
        self.window.geometry('450x500')
        self.window.protocol("WM_DELETE_WINDOW", self.quitprogram)
        
        Label(self.window, text=self.maintext, font=bfont35).pack()

        if self.maintext == 'Welcome':
            Label(self.window, text='Made by Adam', font=font24).pack()


        if CheckFile() and image:
            self.frame1 = Frame(self.window)

            Label(self.frame1, text='Question File - ', font=font20).pack(side=LEFT)
            Label(self.frame1, image=self.tick).pack(side=LEFT)

            self.frame1.pack(pady=50)

            Questions() #this functions gets the questions needed for the program to run

        elif CheckFile() == False:
            self.frame1 = Frame(self.window)

            Label(self.frame1, text='Question File - ', font=font20).pack(side=LEFT)
            Label(self.frame1, image=self.cross).pack(side=LEFT)

            self.frame1.pack(pady=50)

            messagebox.showerror(message='File Not Found, please restart the program')
            self.window.destroy()
            sys.exit()
            return


        self.frame2 = Frame(self.window)
        Label(self.frame2, text='Category - ', font=font20).pack(side=LEFT)
        self.combo = ttk.Combobox(self.frame2, font=font20, values=category)
        self.combo.pack(side=LEFT)
        self.frame2.pack()

        #changing the button commands to destroy the last question window if self.maintext of the Welcome page is 'Change Category'
        if maintext == 'Change Category':
            button = Button(self.window, text='START', font=bfont35, width=15, fg='white', bg='green', command=lambda: self.controller(self.combo.get(), destroymain=True))
            self.window.geometry('450x250')
        else:
            button = Button(self.window, text='START', font=bfont35, width=15, fg='white', bg='green', command=lambda: self.controller(self.combo.get()))
        button.pack(pady=10)


        if not questionList:
            print('Need to code NoQuestions() function')



    def controller(self, start, destroymain=False):
        '''Checks the category and makes sure that questions are in questionList
            Can destory the last window if passed destroymain=True'''
        global main #has to be global to be used in other classes
        
        if questionList and start in category: #checking that there are questions and the category given is valid
            if destroymain:
                main.window.destroy()
                
            self.window.destroy()
            main = MainGUI(start)

        elif start not in category:
            messagebox.showinfo(message='Please select a category')

    def quitprogram(self, event=None):
        '''Closes the window before ending the application'''
        self.window.destroy()
        sys.exit()



class MainGUI:
    def __init__(self, startcategory):
        ''' self.questions = list of questions
            self.categories = list of catagories
            self.category = the catagory chosen
            self.window = the toplevel window
            self.string = string var - question on screen
            self.question = question on screen
            self.answer = answer to question on screen
            self.questionrow = row of the question'''
   
        self.questions = questionList
        self.categories = category
        self.category = startcategory

        if self.category == None:
            return

        self.window = Toplevel()
        self.window.geometry('700x350')
        self.window.title(self.category.title())
        self.window.protocol("WM_DELETE_WINDOW", self.quitprogram)

        #finding the colour
        for item in self.questions:
            if item[0] == self.category:
                self.colour = item[3]
                break

        self.string = StringVar()

        Label(self.window, text=self.category.title(), font=bfont35, fg=self.colour).pack()
        Label(self.window, textvariable=self.string, font=font24, fg=self.colour, wraplength=700).pack()

        self.question = ''
        self.answer = ''
        self.randomquestion()

        self.frame1 = Frame(self.window)
        self.entry = Entry(self.frame1, font=font24, width=30) #focusin & focusout binding
        self.entry.focus_set()
        self.entry.bind('<Return>',self.checkanswer)
        self.entry.pack()

        self.newbutton = Button(self.frame1, font=font20, fg='white', bg=self.colour, text='New Question', command=self.randomquestion)
        self.newbutton.pack(side=LEFT, pady=10)

        self.newbutton = Button(self.frame1, font=font20, fg='white', bg=self.colour, text='Check Answer!', width=20, command=self.checkanswer)
        self.newbutton.pack(side=RIGHT, pady=10)
        
        self.frame1.pack(side=BOTTOM, pady=10)

        #making the menubar
        self.menubar = Menu(self.window)
        #file menu
        self.filemenu = Menu(self.menubar, tearoff=0)
        self.filemenu.add_command(label='Different Question', command=self.randomquestion)
        self.filemenu.add_command(label='Different Category', command=self.changecategory)
        self.filemenu.add_separator()
        self.filemenu.add_command(label='Quit', command=self.quitprogram)
        self.menubar.add_cascade(label='File', menu=self.filemenu)
        #edit menu
        self.editmenu = Menu(self.menubar, tearoff=0)
        self.editmenu.add_command(label='Edit Question', command=self.editquestion)
        self.editmenu.add_command(label='Edit Category', command=self.editcategory)
        self.menubar.add_cascade(label='Edit', menu=self.editmenu)
        #new menu
        self.newmenu = Menu(self.menubar, tearoff=0)
        self.newmenu.add_command(label='New Question', command=self.newquestion)
        self.newmenu.add_command(label='New Category', command=self.newcategory)
        self.menubar.add_cascade(label='New', menu=self.newmenu)

        self.window.config(menu=self.menubar)
        
    def quitprogram(self, event=None):
        '''Closes the window before ending the application'''
        self.window.destroy()
        sys.exit()

    def checkanswer(self, event=None):
        '''Checks the answer against the current question'''
        if self.entry.get().lower() == self.answer.lower():
            print('correct')
            self.entry.delete(0,END)
            self.randomquestion(self)
        elif self.entry.get() != '':
            print('Wrong, the answer is -',self.answer)

    def randomquestion(self, event=None):
        '''Changes self.string into a different question from the category passed'''

        #making sure that categories with 1 question dont infinitely loop
        count = 0
        for question in questionList:
            if question[0] == self.category:
                count += 1
        if count <= 1 and self.question != '':
            return
        
        while True:
            choice = random.choice(questionList)
            if choice[0] == self.category and choice[2] != self.question: #makes sure not repeated after eachother
                self.question = choice[2]
                self.answer = choice[1]
                self.questionrow = choice
                self.string.set(self.question)
                break

    def changecategory(self, event=None):
        '''Changes the category'''
        welcome = Welcome('Change Category', image=False)
        
    def editquestion(self, event=None):
        '''Edit question window controller'''
        edit = NewOrEditQuestion(self, edit=True)

    def newquestion(self, event=None):
        '''Create new question window controller'''
        new = NewOrEditQuestion(self, new=True)

    def refreshlist(self, event=None):
        '''Refreshes the questions and resets the class variables'''
        Questions()
        self.questions = questionList
        self.categories = category

    def newcategory(self, event=None):
        '''Create new category window controller'''
        ncat = NewOrEditQuestion(self, new=True, category=True)

    def editcategory(self, event=None):
        '''Edit category window controller'''
        editcat = EditCategory(self)
        


class NewOrEditQuestion:
    def __init__(self, main, edit=False, new=False, category=False):
        '''main parameter is the main windowin order to get the variables such as .answer'''

        #making sure that 1 type of window is selected, not none or both
        if (edit == False and new == False) or (new == True and edit == True):
            raise AttributeError('Must have 1 type selected')
            return

        self.window = Toplevel()
        self.window.geometry('550x350')
        self.window.resizable(0,0)

        self.colour = 'red'

        ## TITLE AND LABEL
        if edit == True:
            self.window.title('Edit')
            Label(self.window, text='Edit Question', font=bfont35).pack(padx=10)
        elif new == True and category == False:
            self.window.title('New')
            Label(self.window, text='New Question', font=bfont35).pack(padx=10)
        elif category == True:
            self.window.title('Category')
            Label(self.window, text='New Question for Category', font=bfont35).pack(padx=10)


        ## DROPDOWN OR ENTRY
        self.frame1 = Frame(self.window)
        if category == True: #changing dropdown into entry if category
            Label(self.frame1, text='Category name', font=font20).pack(side=LEFT, padx=10)
            self.categoryentry = Entry(self.frame1, font=font20)
            self.categoryentry.pack(side=LEFT, padx=10)
        else:
            Label(self.frame1, text='Choose a category', font=font20).pack(side=LEFT, padx=10)
            self.dropdown = ttk.Combobox(self.frame1, font=font20, values=main.categories)
            self.dropdown.pack(side=LEFT, padx=10)
            
        if edit == True or (new == True and category == False):
            self.dropdown.current(main.categories.index(main.category)) #finding the index of the current category

        self.frame1.pack()

        self.scrolledtext = ScrolledText(self.window, font=font20, width=35, height=5, wrap=WORD)
        self.scrolledtext.pack(pady=10)

        self.frame2 = Frame(self.window)
        self.ansentry = Entry(self.frame2, font=font20, width=30)
        self.ansentry.pack(side=LEFT)

        ## ADDING COLOUR BUTTON
        if category == True:
            self.b = Button(self.window, text='Click to change category colour', bg='deep sky blue', fg='white', font=font20, command=self.getcolour).pack(pady=5, padx=5)
            self.window.geometry('550x450')


        if edit == True: #edit question
            self.button = Button(self.frame2, text='Save', bg='deep sky blue', fg='white', font=font20, command=self.editquestion)
            self.scrolledtext.insert(END,main.question)
            self.ansentry.insert(0,main.answer)

        elif new == True and category == False: #new question
            self.button = Button(self.frame2, text='Create', bg='deep sky blue', fg='white', font=font20, command=self.newquestion)

        elif category == True: #new category
            self.button = Button(self.frame2, text='Create', bg='deep sky blue', fg='white' ,font=font20, command=self.newcategory)

        self.button.pack(side=LEFT, padx=10)
        self.frame2.pack(pady=10)


    def getcolour(self, event=None):
        '''Gets the colour that the user enters when making a category'''
        self.colour = colorchooser.askcolor()[1]


    def editquestion(self, event=None):
        '''Edits the question using a temporary file'''
        global questionList

        category = self.dropdown.get()
        question = self.scrolledtext.get(0.0,'end-1c')
        answer = self.ansentry.get()
        colour = main.colour
        itemindex = 0

        if category == main.category and question == main.question and answer == main.answer: #no changes made
            messagebox.showinfo(message='You have made no changes!')
            return

        elif category in main.categories: #valid category
            
            for i in range(len(questionList)):
                if questionList[i] == main.questionrow:
                    itemindex = i #finding index position of question

            #print(questionList[itemindex])
            main.questions[itemindex] = [category,answer,question,colour]
            questionList[itemindex] = [category,answer,question,colour]
            #print(questionList[itemindex])

            with open(dataFile,'w',newline='\n') as data:
                for item in main.questions:
                    csv.writer(data).writerow(item)

        main.refreshlist()
        main.randomquestion()
        self.window.destroy()
        
    def newquestion(self, event=None):
        '''Adds a new question to the dataFile'''
        category = self.dropdown.get()
        question = self.scrolledtext.get(0.0,'end-1c')
        answer = self.ansentry.get()
        colour = main.colour

        #print([category, answer, question, colour])

        with open(dataFile,'a',newline='\n') as data:
            if category in main.categories:
                csv.writer(data).writerow([category, answer, question, colour])

        messagebox.showinfo(message='New Question created!')
        self.window.destroy()
        main.refreshlist()


    def newcategory(self, event=None):
        '''Creates a question for a new category'''
        if self.colour == 'red':
            messagebox.showinfo(message='Please select a category colour')
            return
        
        category = self.categoryentry.get()
        question = self.scrolledtext.get(0.0,'end-1c')
        answer = self.ansentry.get()
        colour = self.colour

        #print([category, answer, question, colour])

        with open(dataFile,'a',newline='\n') as data:
            csv.writer(data).writerow([category, answer, question, colour])

        messagebox.showinfo(message='New category made!')
        main.refreshlist()
        self.window.destroy()

class EditCategory:
    def __init__(self, main):
        self.window = Toplevel()
        self.window.title('Edit Category')
        self.window.geometry('450x300')
        
        self.buttoncolour = main.colour #setting the colour of the button

        Label(self.window, text='Edit Category', font=bfont35, fg=main.colour).pack()

        self.frame1 = Frame(self.window)
        Label(self.frame1, text='Name', font=font20, fg=main.colour).pack(side=LEFT, padx=5)
        self.categoryname = Entry(self.frame1, font=font20)
        self.categoryname.insert(0, main.category)
        self.categoryname.pack(side=LEFT, padx=5)
        self.frame1.pack(pady=10, padx=10)

        self.frame2 = Frame(self.window)
        Label(self.frame2, text='Colour', font=font20, fg=main.colour).pack(side=LEFT, padx=5)
        self.button = Button(self.frame2, font=font20, bg=self.buttoncolour, width=3, command=self.getcolour)
        self.button.pack(side=LEFT, padx=5)
        self.frame2.pack(pady=10, padx=10)

        self.updatebutton = Button(self.window, font=font20, text='Save', bg=self.buttoncolour, fg='white' , width=20, command=self.update)
        self.updatebutton.pack(pady=5, padx=5)


    def getcolour(self, event=None):
        '''Updates self.buttoncolour to chosen colour'''
        self.buttoncolour = colorchooser.askcolor()[1]
        self.button['bg'] = self.buttoncolour

    def update(self, event=None):
        global questionList
        '''Updates the file to apply changes made by the user'''

        newcolour = self.buttoncolour
        newname = self.categoryname.get()
        
        for item in questionList: #checking for it in questionList before editing it
            if item[0] == main.category:
                item[3] = self.buttoncolour
                if newname:
                    item[0] = newname


        with open(dataFile,'w',newline='\n') as data:
            for item in questionList:
                csv.writer(data).writerow(item)

        messagebox.showinfo(message='Category Updated! Change the category to the current one to see the change')
        self.window.destroy()
        main.refreshlist()

def NoQuestions():
    '''A globally availiable function if there is no questions in the file'''
    pass


def CheckFile():
    '''Returns True if the file is there, and False if not'''
    try:
        open(dataFile,'r').close()
        return True
    except FileNotFoundError:
        return False



## Code that is ran to start the program
welcomePage = Welcome('Welcome')
root.mainloop()
